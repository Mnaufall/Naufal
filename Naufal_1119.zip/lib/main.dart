import 'package:flutter/material.dart';

import 'package:flutter_app/pages/download_sertif.dart';
import 'package:flutter_app/pages/homescreen.dart';
import 'package:flutter_app/pages/scan_qr.dart';
import 'package:flutter_app/pages/scan_qr_1.dart';
import 'package:flutter_app/pages/scan_qr_2.dart';


void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter App',
      home: Scaffold(

        body: DownloadSertif(),
        // body: Homescreen(),
        // body: ScanQr(),
        // body: ScanQr1(),
        // body: ScanQr2(),

      ),
    );
  }
}
